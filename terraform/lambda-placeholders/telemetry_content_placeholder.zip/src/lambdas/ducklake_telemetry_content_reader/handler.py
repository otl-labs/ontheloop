import json


def handler(event, context=None):
    return {
        "statusCode": 503,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"error": "content_reader_not_deployed"}),
    }
